package es.ucm.fdi.ici.c2021.practica5.grupo09.CBRengine;

public enum INTER{
	CRUZ,
	T_HOR, //derecha abajo izquierda 
	L_INVER, //abajo, izquieda, arriba
	T_INVER, //izquierda arriba derecha
	L_VERT //arriba, derecha abajo
}
